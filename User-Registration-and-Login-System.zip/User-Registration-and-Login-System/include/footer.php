      <footer class="py-4 bg-dark text-white-50 fixed-bottom">
        <div class="container text-center">
          <small>Developed by <a class="text-white" href="" target="_blank"> Tineth Pathiarge</a> | All Rights Reserved. © 2024</small>
        </div>
      </footer>

      <!-- Bootstrap core JavaScript-->
      <script src="vendor/jquery-3.4.1.min.js"></script>
      <script src="vendor/bootstrap/popper.min.js"></script>
      <script src="vendor/bootstrap/bootstrap.min.js"></script>
  </body>

</html>