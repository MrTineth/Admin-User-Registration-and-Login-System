      <footer class="py-4 bg-primary text-white-50">
        <div class="container text-center">
          <small>Developed by <a class="text-white" href="" target="_blank"> Tineth Pathirage</a> | All Rights Reserved. © 2024</small>
        </div>
      </footer>

      <!-- Bootstrap core JavaScript-->
      <script src="../vendor/jquery-3.4.1.min.js"></script>
      <script src="../vendor/bootstrap/popper.min.js"></script>
      <script src="../vendor/bootstrap/bootstrap.min.js"></script>

      <!-- Core plugin JavaScript-->
      <script src="../vendor/datatables/jquery.dataTables.js"></script>
      <script src="../vendor/datatables/dataTables.bootstrap4.js"></script>

      <!-- Page level plugin JavaScript-->
      <script src="../vendor/chart.js/Chart.min.js"></script>
    </body>

</html>